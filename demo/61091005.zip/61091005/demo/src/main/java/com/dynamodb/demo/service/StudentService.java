package com.dynamodb.demo.service;

import java.util.List;

import com.dynamodb.demo.model.StudentDTO;

public interface StudentService {
	List<StudentDTO> getAllStudents();

	StudentDTO getStudentById(String id);

	StudentDTO createNewStudent(StudentDTO dto);

	StudentDTO updateStudent(String id, StudentDTO dto);

    void deleteStudent(String id);

}
