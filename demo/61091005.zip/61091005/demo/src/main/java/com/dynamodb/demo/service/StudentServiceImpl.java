package com.dynamodb.demo.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.dynamodb.demo.model.Student;
import com.dynamodb.demo.model.StudentDTO;

@Service
public class StudentServiceImpl implements StudentService{
	
	 private final DynamoDBMapper dynamoDBMapper;

	    public StudentServiceImpl(DynamoDBMapper dynamoDBMapper) {
	        this.dynamoDBMapper = dynamoDBMapper;
	    }

	    public List<StudentDTO> getAllStudents() {
	        DynamoDBScanExpression scanExpression = new DynamoDBScanExpression();
	        List<Student> products = dynamoDBMapper.scan(Student.class, scanExpression);
	        return products.stream().map(this::convertToDTO).collect(Collectors.toList());
	    }

	    public StudentDTO getStudentById(String id) {
	    	Student Student = dynamoDBMapper.load(Student.class, id);
	        return convertToDTO(Student);
	    }

	    public StudentDTO createNewStudent(StudentDTO dto) {
	    	Student student = new Student();
	        BeanUtils.copyProperties(dto, student);

	        dynamoDBMapper.save(student);

	        return convertToDTO(student);
	    }

	    public StudentDTO updateStudent(String id, StudentDTO dto) {
	    	Student student = dynamoDBMapper.load(Student.class, id);
	        BeanUtils.copyProperties(dto, student);

	        dynamoDBMapper.save(student);

	        return convertToDTO(student);
	    }

	    public void deleteStudent(String id) {
	        Student student = dynamoDBMapper.load(Student.class, id);
	        if (student != null) {
	            dynamoDBMapper.delete(student);
	        }
	    }

	    private StudentDTO convertToDTO(Student student) {
	    	StudentDTO dto = new StudentDTO();
	        BeanUtils.copyProperties(student, dto);
	        return dto;
	    }
}
