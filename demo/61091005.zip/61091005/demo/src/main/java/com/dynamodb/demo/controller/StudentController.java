package com.dynamodb.demo.controller;

import org.springframework.web.bind.annotation.*;

import com.dynamodb.demo.model.StudentDTO;
import com.dynamodb.demo.service.StudentService;

import java.util.List;

@RestController
@RequestMapping("/students")
public class StudentController {
	
	private final StudentService studentService;

    public StudentController(StudentService studentService) {
    	System.out.println("Insdie---scontrolelr");
        this.studentService = studentService;
    }

    @GetMapping
    public List<StudentDTO> getAllStudents() {
    	System.out.println("inside students---");
        return studentService.getAllStudents();
    }

    @GetMapping("/{id}")
    public StudentDTO getStudentById(@PathVariable String id) {
        return studentService.getStudentById(id);
    }

    @PostMapping
    public StudentDTO createNewStudent(@RequestBody StudentDTO studentDTO) {
    	System.out.println("create student");
        return studentService.createNewStudent(studentDTO);
    }

    @PutMapping("/{id}")
    public StudentDTO updateStudent(@PathVariable String id, @RequestBody StudentDTO studentDTO) {
        return studentService.updateStudent(id, studentDTO);
    }

    @DeleteMapping("/{id}")
    public void deleteStudent(@PathVariable String id) {
    	studentService.deleteStudent(id);
    }
}
